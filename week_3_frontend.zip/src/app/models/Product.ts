interface Sach {
    id: number;
    name: string;
}