import { NgModule } from "@angular/core";
import { NotFoundComponent } from "./not-found.component";

@NgModule({
    declarations: [NotFoundComponent],
    imports: [],
    exports: [NotFoundComponent]
})
export class NotFoundModule { }