export interface Todo {
    userId: number;
    id: number;
    title: string;
    complete: boolean;
}